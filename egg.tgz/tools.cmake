# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(pitest-run src/pitest-run.cpp)
set_property(TARGET pitest-run PROPERTY CXX_STANDARD 11)
target_link_libraries(pitest-run lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(scoop-manifest src/scoop-manifest.cpp)
set_property(TARGET scoop-manifest PROPERTY CXX_STANDARD 11)
target_link_libraries(scoop-manifest lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(locale-tests src/locale-tests.cpp)
set_property(TARGET locale-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(locale-tests lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

add_executable(build-timing src/build-timing.cpp)
set_property(TARGET build-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(build-timing lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

add_executable(compile-time-report src/compile-time-report.cpp)
set_property(TARGET compile-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(compile-time-report lionss pthread)

add_executable(windows-arm64 src/windows-arm64.cpp)
set_property(TARGET windows-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-arm64 lionss pthread)

add_executable(haiku-build src/haiku-build.cpp)
set_property(TARGET haiku-build PROPERTY CXX_STANDARD 11)
target_link_libraries(haiku-build lionss pthread)

add_executable(warm-cache-bench src/warm-cache-bench.cpp)
set_property(TARGET warm-cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(warm-cache-bench lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(valgrind-massif src/valgrind-massif.cpp)
set_property(TARGET valgrind-massif PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-massif lionss pthread)

add_executable(package-appimage src/package-appimage.cpp)
set_property(TARGET package-appimage PROPERTY CXX_STANDARD 11)
target_link_libraries(package-appimage lionss pthread)

add_executable(cxx20-modules src/cxx20-modules.cpp)
set_property(TARGET cxx20-modules PROPERTY CXX_STANDARD 11)
target_link_libraries(cxx20-modules lionss pthread)

add_executable(makefiles-build src/makefiles-build.cpp)
set_property(TARGET makefiles-build PROPERTY CXX_STANDARD 11)
target_link_libraries(makefiles-build lionss pthread)

add_executable(build-no-rtti src/build-no-rtti.cpp)
set_property(TARGET build-no-rtti PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-rtti lionss pthread)

add_executable(nanobench src/nanobench.cpp)
set_property(TARGET nanobench PROPERTY CXX_STANDARD 11)
target_link_libraries(nanobench lionss pthread)

add_executable(lcov-report src/lcov-report.cpp)
set_property(TARGET lcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(lcov-report lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(fuzz-minimize src/fuzz-minimize.cpp)
set_property(TARGET fuzz-minimize PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-minimize lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)


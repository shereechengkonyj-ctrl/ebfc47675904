// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("unity build\n", stdout);
  return lionss_run_workload("unity-build");
}

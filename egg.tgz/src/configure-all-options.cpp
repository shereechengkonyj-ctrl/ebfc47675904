// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("configure all options"); }
int main(){
  announce();
  return lionss_run_workload("configure-all-options");
}

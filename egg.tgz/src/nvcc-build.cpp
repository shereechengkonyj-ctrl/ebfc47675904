// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("nvcc build"); }
int main(){
  announce();
  return lionss_run_workload("nvcc-build");
}
